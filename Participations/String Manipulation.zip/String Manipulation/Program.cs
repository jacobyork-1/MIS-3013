﻿//Jacob York
using System;

namespace String_Manipulation
{
    class Program
    {
        static void Main(string[] args)
        {
            string sentence = "Programming today is a race between software engineers striving to build bigger and better idiot - proof programs, and the universe trying to build bigger and better idiots.So far, the universe is winning.";
           

            Console.WriteLine(sentence);
            Console.WriteLine("What word would you like to search for in the previous sentence?");
            string word = Console.ReadLine();

            Console.WriteLine("What would you like to change the word to?");
            string newWord = Console.ReadLine();

            bool a = sentence.Contains(word);

            if (a is false)
            {
                Console.WriteLine("Sorry, I could not find your word '{word}'");
            }

        }
    }
}
